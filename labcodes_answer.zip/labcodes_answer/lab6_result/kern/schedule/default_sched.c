//#include <defs.h>
//#include <list.h>
//#include <proc.h>
//#include <assert.h>
//#include <default_sched.h>
//
//#define USE_SKEW_HEAP 1
//
///* You should define the BigStride constant here*/
///* LAB6: YOUR CODE */
//#define BIG_STRIDE    0x7FFFFFFF /* ??? */
//
/* The compare function for two skew_heap_node_t's and the
 * corresponding procs*/
//static int
//proc_stride_comp_f(void *a, void *b)
//{
//     struct proc_struct *p = le2proc(a, lab6_run_pool);
//     struct proc_struct *q = le2proc(b, lab6_run_pool);
//     int32_t c = p->lab6_stride - q->lab6_stride;
//     if (c > 0) return 1;
//     else if (c == 0) return 0;
//     else return -1;
//}
//
///*
// * stride_init initializes the run-queue rq with correct assignment for
// * member variables, including:
// *
// *   - run_list: should be a empty list after initialization.
// *   - lab6_run_pool: NULL
// *   - proc_num: 0
// *   - max_time_slice: no need here, the variable would be assigned by the caller.
// *
// * hint: see proj13.1/libs/list.h for routines of the list structures.
// */
//static void
//stride_init(struct run_queue *rq) {
//     /* LAB6: YOUR CODE */
//     list_init(&(rq->run_list));
//     rq->lab6_run_pool = NULL;
//	//memset(&(rq->lab6_run_pool), 0, sizeof(rq->lab6_run_pool));
//
//	rq->proc_num = 0;
//}
//
///*
// * stride_enqueue inserts the process ``proc'' into the run-queue
// * ``rq''. The procedure should verify/initialize the relevant members
// * of ``proc'', and then put the ``lab6_run_pool'' node into the
// * queue(since we use priority queue here). The procedure should also
// * update the meta date in ``rq'' structure.
// *
// * proc->time_slice denotes the time slices allocation for the
// * process, which should set to rq->max_time_slice.
// *
// * hint: see proj13.1/libs/skew_heap.h for routines of the priority
// * queue structures.
// */
//static void
//stride_enqueue(struct run_queue *rq, struct proc_struct *proc) {
//     /* LAB6: YOUR CODE */
//#if USE_SKEW_HEAP
//     rq->lab6_run_pool =
//          skew_heap_insert(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_stride_comp_f);
//#else
//     assert(list_empty(&(proc->run_link)));
//     list_add_before(&(rq->run_list), &(proc->run_link));
//#endif
//     if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {
//          proc->time_slice = rq->max_time_slice;
//     }
//     proc->rq = rq;
//     rq->proc_num ++;
//}
//
///*
// * stride_dequeue removes the process ``proc'' from the run-queue
// * ``rq'', the operation would be finished by the skew_heap_remove
// * operations. Remember to update the ``rq'' structure.
// *
// * hint: see proj13.1/libs/skew_heap.h for routines of the priority
// * queue structures.
// */
//static void
//stride_dequeue(struct run_queue *rq, struct proc_struct *proc) {
//     /* LAB6: YOUR CODE */
//#if USE_SKEW_HEAP
//     rq->lab6_run_pool =
//          skew_heap_remove(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_stride_comp_f);
//#else
//     assert(!list_empty(&(proc->run_link)) && proc->rq == rq);
//     list_del_init(&(proc->run_link));
//#endif
//     rq->proc_num --;
//}
///*
// * stride_pick_next pick the element from the ``run-queue'', with the
// * minimum value of stride, and returns the corresponding process
// * pointer. The process pointer would be calculated by macro le2proc,
// * see proj13.1/kern/process/proc.h for definition. Return NULL if
// * there is no process in the queue.
// *
// * When one proc structure is selected, remember to update the stride
// * property of the proc. (stride += BIG_STRIDE / priority)
// *
// * hint: see proj13.1/libs/skew_heap.h for routines of the priority
// * queue structures.
// */
//static struct proc_struct *
//stride_pick_next(struct run_queue *rq) {
//     /* LAB6: YOUR CODE */
//	// 添加调试信息
//	//cprintf("Picking next process\n");
//#if USE_SKEW_HEAP
//     if (rq->lab6_run_pool == NULL) return NULL;
//     struct proc_struct *p = le2proc(rq->lab6_run_pool, lab6_run_pool);
//#else
//     list_entry_t *le = list_next(&(rq->run_list));
//
//     if (le == &rq->run_list)
//          return NULL;
//
//     struct proc_struct *p = le2proc(le, run_link);
//     le = list_next(le);
//     while (le != &rq->run_list)
//     {
//          struct proc_struct *q = le2proc(le, run_link);
//          if ((int32_t)(p->lab6_stride - q->lab6_stride) > 0)
//               p = q;
//          le = list_next(le);
//     }
//#endif
//     if (p->lab6_priority == 0)
//          p->lab6_stride += BIG_STRIDE;
//     else p->lab6_stride += BIG_STRIDE / p->lab6_priority;
//     // 调试信息
//     //cprintf("Selected process: %d, stride: %d\n", p->pid, p->lab6_stride);
//     return p;
//}
//
//static struct proc_struct *
//RR_pick_next(struct run_queue *rq) {
//    list_entry_t *le = list_next(&(rq->run_list)); //选取就绪进程队列rq中的队头队列元素
//    if (le != &(rq->run_list)) {//取得就绪进程
//        return le2proc(le, run_link);//返回进程控制块指针
//    }
//    return NULL;
//}
//
//
///*
// * stride_proc_tick works with the tick event of current process. You
// * should check whether the time slices for current process is
// * exhausted and update the proc struct ``proc''. proc->time_slice
// * denotes the time slices left for current
// * process. proc->need_resched is the flag variable for process
// * switching.
// */
//static void
//stride_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
//     /* LAB6: YOUR CODE */
//     if (proc->time_slice > 0) {
//          proc->time_slice --;
//     }
//     if (proc->time_slice == 0) {
//          proc->need_resched = 1;
//     }
//     // 调试信息
//     //cprintf("Process %d, time slice: %d\n", proc->pid, proc->time_slice);
//}
//
//struct sched_class default_sched_class = {
//     .name = "stride_scheduler",
//     .init = stride_init,
//     .enqueue = stride_enqueue,
//     .dequeue = stride_dequeue,
//     .pick_next = stride_pick_next,
//     .proc_tick = stride_proc_tick,
//};

//2
//#include <defs.h>
//#include <list.h>
//#include <proc.h>
//#include <assert.h>
//#include <default_sched.h>
////#include <rand.c>
//
/////* Simple random number generator */
////static unsigned long next = 1;
////
/////* RAND_MAX assumed to be 32767 */
////int rand(void) {
////    next = next * 1103515245 + 12345;
////    return (unsigned int)(next / 65536) % 32768;
////}
////
////void srand(unsigned int seed) {
////    next = seed;
////}
//
//static void
//lottery_init(struct run_queue *rq) {
//    list_init(&(rq->run_list));
//
//    rq->proc_num = 0;
//    rq->total_tickets = 500;//
//}
//
//static void
//lottery_enqueue(struct run_queue *rq, struct proc_struct *proc) {
//    cprintf("1\n");
////	cprintf(proc->run_link);
//	cprintf("2\n");
//    cprintf(&(proc->run_link));
//    cprintf("3\n");
//	assert(list_empty(&(proc->run_link)));
//
//    list_add_before(&(rq->run_list), &(proc->run_link));
//    if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {
//        proc->time_slice = rq->max_time_slice;
//    }
//    proc->rq = rq;
//    rq->proc_num ++;
////    // 设置进程的彩票起始编号和范围
////	proc->ticket_start = rq->total_tickets;
////	proc->ticket_count = 100; // 每个进程拥有100个彩票
////	rq->total_tickets += proc->ticket_count;
//
//    // 打印每个进程的彩票范围
//    cprintf("Process %d: tickets [%d, %d)\n", proc->pid, proc->ticket_start, proc->ticket_start + proc->ticket_count);
//}
//
//static void
//lottery_dequeue(struct run_queue *rq, struct proc_struct *proc) {
//    assert(!list_empty(&(proc->run_link)) && proc->rq == rq);
//    list_del_init(&(proc->run_link));
//    rq->proc_num --;
//}
//
//static struct proc_struct *
//lottery_pick_next(struct run_queue *rq) {
//    if (rq->total_tickets == 0) {
//        return NULL;
//    }
//    int winner_ticket = rand() % rq->total_tickets+1;
//
//    cprintf("%d\n",winner_ticket);
//
//    list_entry_t *le = list_next(&(rq->run_list));
//    while (le != &(rq->run_list)) {
//    	struct proc_struct *proc = le2proc(le, run_link);
//		if (winner_ticket >= proc->ticket_start &&
//			winner_ticket < proc->ticket_start + proc->ticket_count) {
//			return proc;
//		}
//        le = list_next(le);
//    }
//    return NULL;
//}
//
//static void
//lottery_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
//    if (proc->time_slice > 0) {
//        proc->time_slice --;
//    }
//    if (proc->time_slice == 0) {
//        proc->need_resched = 1;
//    }
//}
//
//struct sched_class default_sched_class = {
//    .name = "lottery_scheduler",
//    .init = lottery_init,
//    .enqueue = lottery_enqueue,
//    .dequeue = lottery_dequeue,
//    .pick_next = lottery_pick_next,
//    .proc_tick = lottery_proc_tick,
//};

//3
//#include <defs.h>
//#include <list.h>
//#include <proc.h>
//#include <assert.h>
//#include <default_sched.h>
//#include <skew_heap.h>
////#include <random.h>
//
//static int
//proc_stride_comp_f(void *a, void *b)
//{
//     struct proc_struct *p = le2proc(a, lab6_run_pool);
//     struct proc_struct *q = le2proc(b, lab6_run_pool);
//     int32_t c = p->lab6_stride - q->lab6_stride;
//     if (c > 0) return 1;
//     else if (c == 0) return 0;
//     else return -1;
//}
//
//// 彩票调度相关的数据初始化
//static void
//lottery_init(struct run_queue *rq) {
//    list_init(&(rq->run_list));
//    rq->lab6_run_pool = NULL; // 初始化斜堆
//    rq->proc_num = 0;
//    rq->total_tickets = 0; // 初始化总彩票数为0
//}
//
//// 将进程插入到运行队列中
//static void
//lottery_enqueue(struct run_queue *rq, struct proc_struct *proc) {
//    // 确保进程不在其他队列中
//    assert(list_empty(&(proc->run_link)));
//    rq->lab6_run_pool = skew_heap_insert(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_stride_comp_f); // 插入斜堆
//    if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {
//        proc->time_slice = rq->max_time_slice;
//    }
//    proc->rq = rq;
//    rq->proc_num ++;
//    rq->total_tickets += proc->ticket_count; // 更新总彩票数
//
//    // 打印每个进程的彩票范围
//    cprintf("Process %d: tickets [%d, %d)\n", proc->pid, proc->ticket_start, proc->ticket_start + proc->ticket_count);
//}
//
//// 将进程从运行队列中移除
//static void
//lottery_dequeue(struct run_queue *rq, struct proc_struct *proc) {
//    assert(!list_empty(&(proc->run_link)) && proc->rq == rq); // 确保进程在队列中
//    rq->lab6_run_pool = skew_heap_remove(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_stride_comp_f); // 从斜堆中移除
//    rq->proc_num --;
//    rq->total_tickets -= proc->ticket_count; // 更新总彩票数
//}
//
//// 选择下一个进程
//static struct proc_struct *
//lottery_pick_next(struct run_queue *rq) {
//    if (rq->total_tickets == 0) {
//        return NULL;
//    }
//    int winner_ticket = (rand() % rq->total_tickets) + 1; // 生成1到总彩票数之间的随机数
//    cprintf("Total tickets: %d, Winner ticket: %d\n", rq->total_tickets, winner_ticket);
//
//    list_entry_t *le = list_next(&(rq->run_list));
//    while (le != &(rq->run_list)) {
//        struct proc_struct *proc = le2proc(le, run_link);
//        if (winner_ticket >= proc->ticket_start &&
//            winner_ticket < proc->ticket_start + proc->ticket_count) {
//            return proc;
//        }
//        le = list_next(le);
//    }
//    return NULL;
//}
//
//// 处理时间片到期
//static void
//lottery_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
//    if (proc->time_slice > 0) {
//        proc->time_slice --;
//    }
//    if (proc->time_slice == 0) {
//        proc->need_resched = 1;
//    }
//}
//
//struct sched_class lottery_sched_class = {
//    .name = "lottery_scheduler",
//    .init = lottery_init,
//    .enqueue = lottery_enqueue,
//    .dequeue = lottery_dequeue,
//    .pick_next = lottery_pick_next,
//    .proc_tick = lottery_proc_tick,
//};

//4
#include <defs.h>
#include <list.h>
#include <proc.h>
#include <assert.h>
#include <default_sched.h>
#include <skew_heap.h>
//#include <random.h>

// 彩票调度相关的数据初始化
static void
lottery_init(struct run_queue *rq) {
    list_init(&(rq->run_list));
    rq->lab6_run_pool = NULL; // 初始化斜堆
    rq->proc_num = 0;
    rq->total_tickets = 500; // 总彩票数为500
}

/* The compare function for two skew_heap_node_t's and the
 * corresponding procs */
static int
proc_lottery_comp_f(void *a, void *b)
{
    struct proc_struct *p = le2proc(a, lab6_run_pool);
    struct proc_struct *q = le2proc(b, lab6_run_pool);
    int32_t c = p->ticket_start - q->ticket_start;
    if (c > 0) return 1;
    else if (c == 0) return 0;
    else return -1;
}

// 将进程插入到运行队列中
static void
lottery_enqueue(struct run_queue *rq, struct proc_struct *proc) {
    // 确保进程不在其他队列中
    //cprintf("Enqueuing process %d\n", proc->pid);
    assert(list_empty(&(proc->run_link))); // 调试信息

    rq->lab6_run_pool = skew_heap_insert(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_lottery_comp_f); // 插入斜堆
    if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {
        proc->time_slice = rq->max_time_slice;
    }
    proc->rq = rq;
    rq->proc_num ++;

    // 将进程添加到 run_list
    list_add_before(&(rq->run_list), &(proc->run_link));
    //cprintf("Process %d enqueued successfully\n", proc->pid);
}

// 将进程从运行队列中移除
static void
lottery_dequeue(struct run_queue *rq, struct proc_struct *proc) {
    //cprintf("Dequeuing process %d\n", proc->pid);
    assert(!list_empty(&(proc->run_link)) && proc->rq == rq); // 确保进程在队列中

    rq->lab6_run_pool = skew_heap_remove(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_lottery_comp_f); // 从斜堆中移除
    rq->proc_num --;

    // 将进程从 run_list 中删除
    list_del_init(&(proc->run_link));
    //cprintf("Process %d dequeued successfully\n", proc->pid);
}

// 选择下一个进程
static struct proc_struct *
lottery_pick_next(struct run_queue *rq) {
    if (rq->total_tickets == 0) {
        return NULL;
    }
    int winner_ticket = (rand() % rq->total_tickets) + 1; // 生成1到总彩票数之间的随机数
    //cprintf("Total tickets: %d, Winner ticket: %d\n", rq->total_tickets, winner_ticket);

    struct proc_struct *proc = NULL;
    int current_ticket = 0;
    list_entry_t *le = list_next(&(rq->run_list)); // 使用 run_list 遍历所有进程
    while (le != &(rq->run_list)) {
        proc = le2proc(le, run_link);
        current_ticket += proc->ticket_count;
        if (current_ticket >= winner_ticket) {
            break;
        }
        le = list_next(le);
    }
    return proc;
}

// 处理时间片到期
static void
lottery_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
    if (proc->time_slice > 0) {
        proc->time_slice --;
    }
    if (proc->time_slice == 0) {
        proc->need_resched = 1;
    }
}

struct sched_class default_sched_class = {
    .name = "lottery_scheduler",
    .init = lottery_init,
    .enqueue = lottery_enqueue,
    .dequeue = lottery_dequeue,
    .pick_next = lottery_pick_next,
    .proc_tick = lottery_proc_tick,
};
