//#ifndef __KERN_SCHEDULE_SCHED_RR_H__
//#define __KERN_SCHEDULE_SCHED_RR_H__
//
//#include <sched.h>
//
//extern struct sched_class default_sched_class;
//
//#endif /* !__KERN_SCHEDULE_SCHED_RR_H__ */

#ifndef __KERN_SCHEDULE_DEFAULT_SCHED_H__
#define __KERN_SCHEDULE_DEFAULT_SCHED_H__

#include <list.h>
#include <proc.h>
#include <sched.h>
extern struct sched_class default_sched_class;//lottery_sched_class;// ;//;

//struct run_queue {
//    list_entry_t run_list;
//    int proc_num;
//    int max_time_slice;
//    int total_tickets; // 总的彩票数
//};

#endif /* !__KERN_SCHEDULE_DEFAULT_SCHED_H__ */
