#include <stdio.h>
#include <proc.h>
#include <sem.h>
#include <monitor.h>
#include <assert.h>

#define N 5 
#define SLEEP_TIME 10

semaphore_t write_mutex;
semaphore_t count_mutex;
int ref_count=0;
int value=9;
int read_table[100];

int Read(int id) {
	down(&count_mutex);
	if(ref_count==0)
		down(&write_mutex);
	++ref_count;
	cprintf("there are %d readers accessing the value.\n", ref_count);
	up(&count_mutex);

	int ret = value;
	cprintf("thread %d get %d\n", id, ret);
	read_table[id] = ret;
	do_sleep(SLEEP_TIME);

	down(&count_mutex);
	--ref_count;
	if(ref_count==0)
		up(&write_mutex);
	up(&count_mutex);
	return 0;
}

int Write(void *arg) {
	down(&write_mutex);	
	int* arr = arg;
	cprintf("thread %d change %d to %d\n", arr[0], value, arr[1]);
	value = arr[1];
	up(&write_mutex);
	return 0;
}

//---------- philo1 threads are in the queue.sophers problem using semaphore ----------------------
int state_sema[N]; /* 记录每个人状态的数组 */
/* 信号量是一个特殊的整型变量 */
semaphore_t mutex; /* 临界区互斥 */
semaphore_t s[N]; /* 每个哲学家一个信号量 */

struct proc_struct *proc_sema[N];


int reader_thread(void * arg) 
{
    int i, iter=0;
    i=(int)arg;
    while(iter++<20)
    { /* 无限循环 */
		Read(i);	
        do_sleep(SLEEP_TIME/10);
    }
	cprintf("reader thread %d quit.\n", i);
    return 0;    
}

int writer_thread(void * arg) 
{
    int i, iter=0;
    i=(int)arg;
	int arr[2];
	arr[0] = (int) arg;
    while(iter++<20)
    { 
		arr[1] = i * 10 + iter;
		Write(arr);	
        do_sleep(SLEEP_TIME);
    }
	cprintf("writer thread %d quit.\n", i);
    return 0;    
}


struct proc_struct *philosopher_proc_condvar[N]; // N philosopher
int state_condvar[N];                            // the philosopher's state: EATING, HUNGARY, THINKING  
monitor_t mt, *mtp=&mt;                                    // mp is mutex semaphore for monitor's procedures


void check_sync(void){

    int i;

    //check semaphores
	sem_init(&write_mutex, 1);
	sem_init(&count_mutex, 1);
	write_mutex.name = "write";
	count_mutex.name = "count";
    for(i=0;i<10;i++){
        int pid = kernel_thread(reader_thread, (void *)i, 0);
        if (pid <= 0) {
            panic("Create reader %d fail.", i);
        }
    }
    for(i=0;i<10;i++){
        int pid = kernel_thread(writer_thread, (void *)i, 0);
        if (pid <= 0) {
            panic("Create writer %d fail.", i);
        }
    }
}
